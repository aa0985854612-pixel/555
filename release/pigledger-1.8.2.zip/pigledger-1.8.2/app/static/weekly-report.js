'use strict';
/* Entry-anchored weekly sheets use a read-only server report, never client stock deltas. */
(() => {
Object.assign(words,{
 weeklyReport:['肉豬每週紀錄表','Bảng ghi heo thịt hằng tuần'],weeklyOpen:['匯出每週紀錄表','Xuất bảng hằng tuần'],weeklyMake:['產生紀錄表','Tạo bảng'],weeklyChoose:['選擇批次與棟舍','Chọn lứa và chuồng'],weeklyAllBarns:['同批全部棟舍','Tất cả chuồng cùng lứa'],weeklyBasis:['從進場日起每7天一欄；每天登記的資料自動加總。','Mỗi cột 7 ngày kể từ ngày nhập; tự cộng dữ liệu ghi hằng ngày.'],weeklyEntryAge:['進場日齡','Tuổi ngày lúc nhập'],weeklyAgeBasis:['週齡欄從進場當日的「第幾週」起算，每7天遞增；已滿10週起標第11週。','Cột tuổi ghi tuần thứ: đủ 10 tuần là tuần thứ 11, khác số tuần đã đủ.'],weeklyCycle:['週期','Kỳ'],weeklyWeek:['第{n}週','Tuần thứ {n}'],weeklyPeriod:['第{n}期','Kỳ {n}'],weeklyStarts:['起始日','Ngày bắt đầu'],weeklyDates:['統計日期','Ngày thống kê'],weeklyDeaths:['死亡數（隻）','Số chết (con)'],weeklySales:['正常出豬（隻）','Xuất bán (con)'],weeklyCulls:['淘汰數（隻）','Loại thải (con)'],weeklyFeed:['叫料登記量（噸）','Lượng đặt đã ghi (tấn)'],weeklyNotes:['異動摘要','Tóm tắt biến động'],weeklyTotal:['選定期間合計','Tổng kỳ đã chọn'],weeklySurvival:['截至日期累計育成率','Tỷ lệ sống lũy kế đến ngày'],weeklyNone:['—＝資料待補；0＝當週無符合條件的登記；未到日期留空。','— = thiếu dữ liệu; 0 = không có bản ghi phù hợp; ngày tương lai để trống.'],weeklyFeedBasis:['叫料量只統計已指定本批／本棟的登記，不代表到料或實際耗料，也不計入FCR。未指定批次的全場叫料另外列待補，不平均分攤。','Chỉ tính lượng đặt phân bổ rõ cho lứa/chuồng này; không phải nhập hay tiêu thụ, không tính FCR. Đơn chung chưa chỉ định để riêng, không chia đều.'],weeklyPending:['待補資料','Dữ liệu cần bổ sung'],weeklyUnknownDate:['缺日期／來源合計無法分週','Thiếu ngày / tổng nguồn chưa chia tuần'],weeklyUnknownBarn:['棟舍分配待確認','Cần xác nhận phân bổ chuồng'],weeklyUnknownFeed:['全場叫料未指定批次','Đơn chung chưa chỉ định lứa'],weeklyKnown:['已知','Đã biết'],weeklyObserved:['資料統計至','Dữ liệu tính đến'],weeklyCurrent:['累計（非期間合計）','Lũy kế (khác tổng kỳ)'],weeklyLoading:['正在整理已儲存紀錄…','Đang tổng hợp bản ghi đã lưu…'],weeklyFailure:['無法產生報表，請重試。','Không tạo được bảng, hãy thử lại.'],weeklyMore:['另有{n}筆，詳見CSV明細','Còn {n} mục; xem chi tiết CSV'],weeklyScope:['匯出範圍','Phạm vi xuất']
});
Object.assign(errorWords,{weekly_choose_batch:['請先選擇一個批次；可以選整批或其中一棟。','Chọn một lứa, có thể toàn lứa hoặc một chuồng.'],weekly_period_too_long:['一次報表最多三年，請縮小日期範圍。','Mỗi bảng tối đa ba năm; thu hẹp khoảng ngày.']});
const base={build,clickAction,translate,enter};
let report=null,reportUser=null,serial=0,printing=false,title=null;
const el=id=>document.getElementById(id),safe=esc;
function label(key,n){return t(key).replace('{n}',n);}
function resetPrint(){if(title!==null){document.title=title;title=null;}printing=false;el('weekly-print-root')?.replaceChildren();}
function chosen(){return data?.batches.find(b=>(b._cohort_key||b.name+'|'+b.entry_date)===el('weekly-cohort').value);}
function syncBarns(resetDates=false){
 const key=el('weekly-cohort').value,selected=el('weekly-barn').value;
 const bs=data?.batches.filter(b=>(b._cohort_key||b.name+'|'+b.entry_date)===key)||[];
 el('weekly-barn').innerHTML=`<option value="">${t('weeklyAllBarns')}</option>`+bs.map(b=>`<option value="${safe(b.barn_id)}">${safe(data.barns.find(x=>x.id===b.barn_id)?.name||'—')}</option>`).join('');
 if(bs.some(b=>b.barn_id===selected))el('weekly-barn').value=selected;
 if(resetDates){el('weekly-from').value=chosen()?.entry_date||'';el('weekly-to').value=today();}
}
function openWeekly(){
 if(!data)return;report=null;el('weekly-sheet-body').replaceChildren();el('weekly-export-actions').hidden=true;el('weekly-error').textContent='';
 const cohorts=(data.cohorts||[]).filter(c=>!c.archive),f=current==='daily'?el('movement-form'):el('stats-filter');
 const options=cohorts.map(c=>`<option value="${safe(c.key)}">${safe(c.name)}｜${safe(c.barns.join('、'))} · ${safe(c.entry_date)}</option>`).join('');
 el('weekly-cohort').innerHTML=`<option value="">${t('choose')}</option>`+options;
 const b=data.batches.find(b=>b.id===val(f,'batch_id'));el('weekly-cohort').value=val(f,'cohort')||(b?(b._cohort_key||b.name+'|'+b.entry_date):'');syncBarns(true);
 if(val(f,'barn_id'))el('weekly-barn').value=val(f,'barn_id');
 if(val(f,'from'))el('weekly-from').value=val(f,'from');if(val(f,'to'))el('weekly-to').value=val(f,'to');
 const d=el('weekly-report-dialog');if(!d.open)d.showModal();d.scrollTop=0;
}
async function generate(e){
 e.preventDefault();const f=el('weekly-report-form');if(!f.reportValidity())return;const mine=++serial,user=me?.id,button=el('weekly-generate');button.disabled=true;el('weekly-error').textContent=t('weeklyLoading');el('weekly-export-actions').hidden=true;report=null;el('weekly-sheet-body').replaceChildren();
 try{
  const q=new URLSearchParams({cohort:el('weekly-cohort').value,from:el('weekly-from').value,to:el('weekly-to').value});if(el('weekly-barn').value)q.set('barn_id',el('weekly-barn').value);
  const result=await api('/api/weekly-report?'+q);if(mine!==serial||me?.id!==user||!el('weekly-report-dialog').open)return;report=result;reportUser=user;render();el('weekly-error').textContent='';el('weekly-export-actions').hidden=false;el('weekly-sheet-body').scrollIntoView({block:'start',behavior:'smooth'});
 }catch(err){if(mine===serial)el('weekly-error').textContent=messageError(err);}finally{if(mine===serial)button.disabled=false;}
}
const metrics=['death','sale','cull','feed_orders'];
const metricKey={death:'weeklyDeaths',sale:'weeklySales',cull:'weeklyCulls',feed_orders:'weeklyFeed'};
function amount(n,key){return n==null?'—':fmt(key==='feed_orders'?n/1000:n,key==='feed_orders'?3:0);}
function basics(){const r=report;return [['batch',r.name],['barn',r.barns.join('、')],['reportEntryDate',r.entry_date],['reportEntryCount',fmt(r.cumulative.entry,0)+' '+t('heads')],['reportEntryMean',r.entry_mean_kg==null?'—':fmt(r.entry_mean_kg)+' kg'],['weeklyEntryAge',r.entry_age_days==null?'—':fmt(r.entry_age_days,0)+' '+t('days')],['weeklyDates',r.from+' → '+r.to],['weeklyObserved',r.observed_to]];}
function notes(w){return w.events.slice(0,8).map(e=>`${e.date.slice(5)} ${e.barn||t('unassigned')} ${t(e.type)}${e.quantity}`).join('；')+(w.events.length>8?'；'+label('weeklyMore',w.events.length-8):'');}
function pendingText(p){return (p.date||t('dateUnknown'))+' · '+(p.reason==='unassigned_order'?t('weeklyUnknownFeed')+' '+fmt(p.kg/1000,3)+' '+t('ton'):t(p.type)+' · '+t(p.reason==='missing_barn'||p.reason==='source_allocation_incomplete'?'weeklyUnknownBarn':'weeklyUnknownDate')+(p.quantity?' · '+p.quantity+' '+t('heads'):''))+(p.source_cell?' · '+p.source_cell:'');}
function markup(){
 const r=report,blocks=[];
 for(let i=0;i<r.weeks.length;i+=13){const ws=r.weeks.slice(i,i+13);blocks.push(`<section class="weekly-block"><div class="weekly-table-wrap"><table class="weekly-table"><thead><tr><th>${t('weeklyCycle')}</th>${ws.map(w=>`<th>${safe(w.age_week==null?label('weeklyPeriod',w.index):label('weeklyWeek',w.age_week))}</th>`).join('')}</tr></thead><tbody><tr><th>${t('weeklyStarts')}</th>${ws.map(w=>`<td>${w.anchor.slice(5)}${w.partial?' *':''}</td>`).join('')}</tr>${metrics.map(k=>`<tr class="weekly-${k}"><th>${t(metricKey[k])}</th>${ws.map(w=>`<td>${w.future?'':amount(w.values[k],k)}</td>`).join('')}</tr>`).join('')}<tr class="weekly-note-row"><th>${t('weeklyNotes')}</th>${ws.map(w=>`<td>${safe(notes(w))}</td>`).join('')}</tr></tbody></table></div></section>`);}
 return `<article class="weekly-sheet"><header class="weekly-heading"><h1>嘉得 · ${t('weeklyReport')}</h1><p>${safe(r.name)}｜${safe(r.barns.join('、'))}</p></header><dl class="weekly-basics">${basics().map(([k,v])=>`<div><dt>${t(k)}</dt><dd>${safe(v)}</dd></div>`).join('')}</dl>${blocks.join('')}<section class="weekly-summary"><div><h2>${t('weeklyTotal')}</h2>${metrics.map(k=>`<p><span>${t(metricKey[k])}</span><strong>${amount(r.totals[k],k)}</strong>${r.totals[k]==null?`<small>${t('weeklyKnown')} ${amount(r.known_totals[k],k)}</small>`:''}</p>`).join('')}</div><div><h2>${t('weeklyCurrent')} · ${r.observed_to}</h2><p><span>${t('remaining')}</span><strong>${fmt(r.cumulative.remaining,0)}</strong></p><p><span>${t('dead')}</span><strong>${fmt(r.cumulative.dead,0)}</strong></p><p><span>${t('weeklySurvival')}</span><strong>${r.cumulative.survival==null?'—':fmt(r.cumulative.survival)+'%'}</strong></p></div></section>${r.pending.length?`<section class="weekly-pending"><h2>${t('weeklyPending')}</h2><ul>${r.pending.map(p=>`<li>${safe(pendingText(p))}</li>`).join('')}</ul></section>`:''}<footer class="weekly-footnotes"><p>${t('weeklyBasis')} ${t('weeklyAgeBasis')}</p><p>${t('weeklyNone')} * ${t('weeklyDates')}：${r.from} → ${r.to}；${t('weeklyObserved')} ${r.observed_to}</p><p>${t('weeklyFeedBasis')}</p><p>${t('cohortFormula')}</p></footer></article>`;
}
function render(){if(report&&reportUser===me?.id)el('weekly-sheet-body').innerHTML=markup();}
function filename(){return `${t('weeklyReport')}_${report.name}_${report.barns.join('-')}_${report.from}_${report.to}`.replace(/[\\/:*?"<>|\r\n]/g,'-');}
function printSheet(){if(!report||reportUser!==me?.id)return;printing=true;el('weekly-print-root').innerHTML=markup();title=document.title;document.title=filename();window.print();}
function csvCell(v){let s=String(v??'');if(/^[\s\uFEFF]*[=+\-@]/.test(s))s="'"+s;return '"'+s.replaceAll('"','""')+'"';}
function csvSheet(){
 if(!report||reportUser!==me?.id)return;const r=report,rows=[[t('weeklyReport')],...basics().map(([k,v])=>[t(k),v]),[],[t('weeklyCycle'),...r.weeks.map(w=>w.age_week==null?label('weeklyPeriod',w.index):label('weeklyWeek',w.age_week))],[t('weeklyStarts'),...r.weeks.map(w=>w.anchor)],[t('weeklyDates'),...r.weeks.map(w=>w.start+' → '+w.end)],...metrics.map(k=>[t(metricKey[k]),...r.weeks.map(w=>w.future?'':w.values[k]==null?'—':k==='feed_orders'?w.values[k]/1000:w.values[k])]),[],[t('weeklyTotal')],...metrics.map(k=>[t(metricKey[k]),r.totals[k]==null?'—':k==='feed_orders'?r.totals[k]/1000:r.totals[k]]),[t('weeklySurvival'),r.cumulative.survival==null?'—':r.cumulative.survival+'%'],[],[t('weeklyNotes')],[t('date'),t('barn'),t('type'),t('quantity'),t('note'),t('sourceCell')],...r.weeks.flatMap(w=>w.events.map(e=>[e.date,e.barn,t(e.type),e.quantity,e.note,e.source_cell])),[],[t('weeklyPending')],...r.pending.map(p=>[pendingText(p)]),[t('weeklyBasis')],[t('weeklyAgeBasis')],[t('weeklyFeedBasis')],[t('weeklyNone')]];
 const url=URL.createObjectURL(new Blob(['\ufeff'+rows.map(row=>row.map(csvCell).join(',')).join('\r\n')],{type:'text/csv;charset=utf-8'})),a=document.createElement('a');a.href=url;a.download=filename()+'.csv';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),10000);
}
build=()=>{
 base.build();el('stats-filter').closest('.card').insertAdjacentHTML('beforeend',`<div class="weekly-entry"><button type="button" id="open-weekly-report">${txt('weeklyOpen')}</button><p class="hint">${txt('weeklyBasis')}</p></div>`);
 el('movement-form').insertAdjacentHTML('afterend',`<div class="weekly-entry"><button type="button" id="open-daily-weekly-report">${txt('weeklyOpen')}</button></div>`);
 document.body.insertAdjacentHTML('beforeend',`<dialog id="weekly-report-dialog" aria-labelledby="weekly-title"><div class="weekly-toolbar"><div class="section-row"><h2 id="weekly-title">${txt('weeklyReport')}</h2><button type="button" id="weekly-close">${txt('reportClose')}</button></div><form id="weekly-report-form"><div class="grid"><label>${txt('batch')}<select id="weekly-cohort" required></select></label><label>${txt('barn')}<select id="weekly-barn"></select></label><label>${txt('from')}<input type="date" id="weekly-from" required></label><label>${txt('to')}<input type="date" id="weekly-to" required></label></div><p class="hint">${txt('weeklyBasis')}</p><button type="submit" id="weekly-generate" class="primary">${txt('weeklyMake')}</button><p id="weekly-error" role="status"></p></form><div id="weekly-export-actions" class="actions" hidden><button type="button" id="weekly-print">${txt('reportPrint')}</button><button type="button" id="weekly-csv">${txt('reportCSV')}</button></div></div><div id="weekly-sheet-body"></div></dialog><div id="weekly-print-root"></div>`);
 el('open-weekly-report').onclick=openWeekly;el('weekly-cohort').onchange=()=>syncBarns(true);el('weekly-report-form').onsubmit=generate;el('weekly-print').onclick=printSheet;el('weekly-csv').onclick=csvSheet;el('weekly-close').onclick=()=>el('weekly-report-dialog').close();el('weekly-report-dialog').addEventListener('close',()=>{serial++;report=null;reportUser=null;el('weekly-generate').disabled=false;resetPrint();});
 el('open-daily-weekly-report').onclick=openWeekly;
 for(const event of ['input','change'])el('weekly-report-form').addEventListener(event,()=>{serial++;report=null;reportUser=null;el('weekly-sheet-body').replaceChildren();el('weekly-export-actions').hidden=true;el('weekly-generate').disabled=false;el('weekly-error').textContent='';});
};
window.addEventListener('beforeprint',()=>{if(printing&&report&&reportUser===me?.id)el('weekly-print-root').innerHTML=markup();});window.addEventListener('afterprint',resetPrint);
document.addEventListener('pigledger:logout',()=>{serial++;report=null;reportUser=null;if(el('weekly-report-dialog').open)el('weekly-report-dialog').close();el('weekly-sheet-body').replaceChildren();resetPrint();});
translate=()=>{base.translate();render();};
enter=async user=>{if(el('weekly-report-dialog')?.open)el('weekly-report-dialog').close();return base.enter(user);};
})();
