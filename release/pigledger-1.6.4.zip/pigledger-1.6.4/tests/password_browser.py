"""Real Chromium: numeric-password constraints and legacy sign-in, isolated data."""
import sys,tempfile,threading,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app.store import Store,VERSION,password_hash,verify_password
from app.server import Server
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1];results=[]
def passed(s):results.append(s);print('PASS',s,flush=True)
with tempfile.TemporaryDirectory() as folder:
 store=Store(Path(folder)/'db');admin=store.create_user('owner','0042');viewer=store.create_user('reader','0077','viewer');legacy='pre-policy-legacy-password';db=store.connect();db.execute('UPDATE users SET hash=? WHERE id=?',(password_hash(legacy),admin['id']));db.commit();db.close();server=Server(('127.0.0.1',0),store);threading.Thread(target=server.serve_forever,daemon=True).start();base=f'http://127.0.0.1:{server.server_port}'
 try:
  with sync_playwright() as p:
   browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);ctx=browser.new_context(viewport={'width':390,'height':844});page=ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto(base)
   def login(target,name,password):
    target.locator('#login-form [name=username]').fill(name);target.locator('#login-form [name=password]').fill(password);target.locator('#login-form button').click();target.wait_for_selector('#workspace:not([hidden])')
   login(page,'owner',legacy);page.locator('nav [href="#settings"]').click();f=page.locator('#password-form');assert not f.locator('[name=current_password]').get_attribute('maxlength');assert not page.locator('#login-form [name=password]').get_attribute('pattern');passed('pre-existing alphanumeric password still signs in and current-password input accepts it')
   for field in ('new_password','confirm_password'):
    el=f.locator(f'[name={field}]');assert el.get_attribute('minlength')=='4' and el.get_attribute('maxlength')=='8' and el.get_attribute('pattern')=='[0-9]{4,8}' and el.get_attribute('inputmode')=='numeric'
   f.locator('[name=current_password]').fill(legacy)
   for value in ('123','ab12','１２３４'):
    f.locator('[name=new_password]').fill(value);assert not f.evaluate('(e)=>e.checkValidity()')
   f.locator('[name=new_password]').fill('0044');f.locator('[name=confirm_password]').fill('0044');page.select_option('#language','vi');assert f.locator('[name=new_password]').input_value()=='0044';assert '4–8' in f.inner_text();page.select_option('#language','zh');f.locator('button').click();page.wait_for_selector('#login-view:not([hidden])');assert page.evaluate('async()=>{const r=await fetch("/api/me");return r.status}')==401;login(page,'owner','0044');passed('4-digit leading-zero password survives translation, saves, and invalidates old session')
   page.locator('nav [href="#settings"]').click();u=page.locator('#user-form');u.locator('[name=username]').fill('new-writer');u.locator('[name=password]').fill('00000007');u.locator('[name=role]').select_option('staff');u.locator('button').click();page.wait_for_function('()=>Array.from(document.querySelectorAll("#user-results .account-name")).some(e=>e.value==="new-writer")');db=store.connect();r=db.execute('SELECT hash FROM users WHERE username=?',('new-writer',)).fetchone();db.close();assert verify_password('00000007',r[0]);passed('admin creates a new account with an 8-digit password without losing leading zeroes')
   row=page.locator(f'[data-user="{viewer["id"]}"]');password=row.locator('[type=password]');password.fill('ab12');seen=[];page.on('request',lambda r:seen.append(r.url) if r.method=='PUT' and '/api/users/' in r.url else None);row.locator('[data-update-user]').click();assert not seen;password.fill('0048');row.locator('[data-update-user]').click();page.wait_for_function("(uid)=>JSON.parse(Array.from(document.querySelectorAll('.user-row')).find(e=>e.dataset.user===uid).querySelector('[type=hidden]').value).revision===2",arg=viewer['id']);db=store.connect();assert verify_password('0048',db.execute('SELECT hash FROM users WHERE id=?',(viewer['id'],)).fetchone()[0]);db.close();passed('admin reset field rejects letters before sending and accepts a 4-digit reset')
   row=page.locator(f'[data-user="{viewer["id"]}"]');row.locator('[data-setup-user]').click();row.locator('.setup-link').wait_for();link=row.locator('.setup-link').input_value();recipient=browser.new_context();q=recipient.new_page();q.goto(link);q.wait_for_selector('#activation-form:not([hidden])');a=q.locator('#activation-form');assert a.locator('[name=password]').get_attribute('pattern')=='[0-9]{4,8}';a.locator('[name=password]').fill('0088');a.locator('[name=confirm]').fill('0088');a.locator('button').click();q.wait_for_selector('#login-form:not([hidden])');login(q,'reader','0088');q.locator('nav [href="#settings"]').click();own=q.locator('#password-form');own.locator('[name=current_password]').fill('0088');own.locator('[name=new_password]').fill('00000099');own.locator('[name=confirm_password]').fill('00000099');own.locator('button').click();q.wait_for_selector('#login-view:not([hidden])');login(q,'reader','00000099');passed('one-use activation accepts 4 digits; viewer can then set own 8-digit password')
   assert not errors;passed('no uncaught JavaScript errors');browser.close()
 finally:server.shutdown();server.server_close()
(root/'artifacts/password-browser-results.json').write_text(json.dumps({'version':VERSION,'mode':'real Chromium, isolated synthetic accounts; no production password changes','passed':results},ensure_ascii=False,indent=2));print('Completed',len(results),'password browser scenarios')
