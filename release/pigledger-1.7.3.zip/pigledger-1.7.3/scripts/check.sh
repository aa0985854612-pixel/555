#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
python3 -m unittest discover -s tests -v
node --check app/static/app.js
node --check app/static/upgrade.js
node --check app/static/redesign.js
node --check app/static/appearance.js
node --check app/static/compact.js
