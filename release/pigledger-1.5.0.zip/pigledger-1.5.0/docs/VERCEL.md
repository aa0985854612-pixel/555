# PigLedger 1.5.0：部署與保留資料

正式網址：https://555-rho-nine.vercel.app/ 。沿用GitHub aa0985854612-pixel/555 main、Vercel pig13／555及既有Turso。

1.5.0沒有SQL結構變更，沿用schema4，不需重建資料庫或重跑初次搬移。新秤重作業欄位及source_voids存於既有records，原紀錄、帳號及安全設定保留。來源作廢是1.5新類型，使用1.5以上程式讀取與還原本版備份。

純程式更新推送main由既有Git整合自動部署。根目錄`./`、Framework Other、Python3.12、保留vercel.json。Production保留TURSO_DATABASE_URL及敏感TURSO_AUTH_TOKEN；不要放NEXT_PUBLIC或前端。環境變數改動需重新部署。

資料更新另走「設定→Excel預覽／匯入」，不是只推前端。本次已備份、核對並保存新版Excel來源；檔名日期與內部統計日不同，使用表內可靠日期。舊歷史表未在新檔出現時仍保留既有來源歷史；人工確認的差異不靜默覆蓋。

更新前後雲端備份已建立，另保留加密離線副本。測試的真實Turso秤重／作廢交易已回滾，沒有永久測試農場紀錄。維護用一次性建置輸入在執行後移除並排除在函式包外，正常Git部署只有程式。

日常用正式網址；完整維護包為**release/pigledger-1.5.0.zip**及同名sha256。手機用Safari／Chrome開啟並加入主畫面。帳號密碼沿用目前設定，不能以程式包中的示範測試帳號登入正式網站。

完整真實測試／模擬／尚未驗收範圍見[1.5.0測試報告](TEST_REPORT_1.5.0.md)。維護環境到正式網域的直接連線受限，正式HTTPS瀏覽器與手機實機尚待驗收。

以下保留前次schema3→4及搬家說明；不是本版日常部署步驟。

## schema3→4歷史更新（已完成，勿重新搬舊資料）

先備份正式資料，使用受保護執行環境的原資料庫金鑰：

```sh
python3 scripts/upgrade_cloud.py --prepare --ensure-role-accounts
# 新版部署Ready後完成版本標記
python3 scripts/upgrade_cloud.py
```

工具先建立持久雲端備份，交易內新增account_security，核對原records／users／requests／audit不變。準備階段保留schema3標記讓新舊部署交接，完成後標記4。一般API不執行schema修改；新版相容準備階段，舊版1.3.1不能直接回滾到標記4資料庫。回滾需使用相容schema4的修正版，或經明確維護安排還原完整備份，不能覆蓋後續正式登記。

`--ensure-role-accounts`只建立缺少的farmviewer／farmeditor／farmmanager，使用不同的隨機未知臨時密碼並要求設定，不重設同名帳號或原farmadmin。原管理員於「設定」產生一次性密碼設定連結，私下交給各人。密碼只存雜湊，管理員不能查看原密碼。

本次更新前已建立雲端備份，另以公開憑證加密取回離線備份，私鑰留在受保護維護環境；更新後再次備份。原55筆紀錄、原帳號保留，新增一份新版Excel來源，補登一筆有來源的入場均重；沒有新增重複棟舍、批次或日常異動。原管理員雜湊逐欄核對未變。詳細農場數字與私密備份不放入公開程式包。

新版Excel先以現況產生預覽與修訂指紋，再交易內核對並套用無爭議來源。已手動登記的事件不重複入帳；衝突批次保留App，來源原文仍可下載。再次匯入相同來源略過。不要把本地過時SQLite再次移入正式庫。

## 備份與搬家

管理員在「設定」下載完整JSON備份並私下保管；唯讀不能下載包含帳號的備份。內部備份與正式資料同庫，請另行保存離線副本。普通程式包不含任何農場資料。`scripts/migrate_cloud.py --db /private/existing.sqlite3`僅供搬到另一個空白資料庫；已使用的正式庫不是每次部署都重跑搬移。

